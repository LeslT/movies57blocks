/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	// The require scope
/******/ 	var __webpack_require__ = {};
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

;// CONCATENATED MODULE: external "dotenv/config"
const config_namespaceObject = require("dotenv/config");
;// CONCATENATED MODULE: external "serverless-http"
const external_serverless_http_namespaceObject = require("serverless-http");
;// CONCATENATED MODULE: external "express"
const external_express_namespaceObject = require("express");
;// CONCATENATED MODULE: external "bcryptjs"
const external_bcryptjs_namespaceObject = require("bcryptjs");
;// CONCATENATED MODULE: external "jsonwebtoken"
const external_jsonwebtoken_namespaceObject = require("jsonwebtoken");
;// CONCATENATED MODULE: ./src/utils/validator.js
const validateEmail = email => {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
};
const validatePassword = password => {
  const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*[!@#?\]]).{10,}$/;
  return passwordRegex.test(password);
};
;// CONCATENATED MODULE: external "mongoose"
const external_mongoose_namespaceObject = require("mongoose");
;// CONCATENATED MODULE: ./src/models/user/userModel.js

const userSchema = new external_mongoose_namespaceObject.Schema({
  email: {
    type: String,
    required: true,
    unique: true
  },
  password: {
    type: String,
    required: true
  },
  favorites: {
    type: Array,
    default: []
  }
});
const User = external_mongoose_namespaceObject.model('User', userSchema);
/* harmony default export */ const userModel = (User);
;// CONCATENATED MODULE: ./src/repository/userRepository.js

class UserRepository {
  async create(user) {
    return await userModel.create(user);
  }
  async findByEmail(email) {
    return await userModel.findOne({
      email
    });
  }
  async findById(id) {
    return await userModel.findById(id);
  }
  async updateByEmail(id, updates) {
    try {
      const user = await userModel.findOneAndUpdate({
        _id: id
      }, {
        $set: updates
      }, {
        new: true
      });
      return user;
    } catch (error) {
      throw new Error('Error updating user by email');
    }
  }
}
const userRepository = new UserRepository();
/* harmony default export */ const repository_userRepository = (userRepository);
;// CONCATENATED MODULE: external "winston"
const external_winston_namespaceObject = require("winston");
;// CONCATENATED MODULE: ./src/lib/log.js

const MESSAGE = Symbol.for('message');
const jsonFormatter = logEntry => {
  const base = {
    timestamp: new Date(),
    app: ''
  };
  const json = Object.assign(base, logEntry);
  logEntry[MESSAGE] = JSON.stringify(json);
  return logEntry;
};
const logger = (0,external_winston_namespaceObject.createLogger)({
  transports: [new external_winston_namespaceObject.transports.Console({
    level: 'info',
    format: (0,external_winston_namespaceObject.format)(jsonFormatter)()
  })],
  exitOnError: false
});
/* harmony default export */ const log = (logger);
;// CONCATENATED MODULE: ./src/controllers/authController.js





const register = async (req, res) => {
  try {
    const {
      email,
      password
    } = req.body;
    log.info('', {
      timestamp: new Date(),
      service: 'REGISTER_CONTROLLER',
      action: 'REGISTER_USER_REQ',
      type: 'INFO',
      message: 'A registration request is received from a user',
      log: email
    });
    console.log('0');
    if (!validateEmail(email)) {
      log.info('', {
        timestamp: new Date(),
        service: 'REGISTER_CONTROLLER',
        action: 'REGISTER_USER_RES',
        type: 'ERROR',
        message: 'Invalid email address',
        log: email
      });
      return res.status(400).json({
        error: 'Invalid email address'
      });
    }
    const existingUser = await repository_userRepository.findByEmail(email);
    console.log('existingUser', existingUser);
    if (existingUser) {
      log.info('', {
        timestamp: new Date(),
        service: 'REGISTER_CONTROLLER',
        action: 'REGISTER_USER_RES',
        type: 'ERROR',
        message: 'Email already registered',
        log: email
      });
      return res.status(400).json({
        error: 'Email already registered'
      });
    }
    if (!validatePassword(password)) {
      log.info('', {
        timestamp: new Date(),
        service: 'REGISTER_CONTROLLER',
        action: 'REGISTER_USER_RES',
        type: 'ERROR',
        message: 'Password must be at least 10 characters long, contain one lowercase letter, one uppercase letter, and one of the following characters: !, @, #, ? or ]',
        log: email
      });
      return res.status(400).json({
        error: 'Password must be at least 10 characters long, contain one lowercase letter, one uppercase letter, and one of the following characters: !, @, #, ? or ]'
      });
    }
    const hashedPassword = await external_bcryptjs_namespaceObject.hash(password, 10);
    const user = await repository_userRepository.create({
      email,
      password: hashedPassword
    });
    log.info('', {
      timestamp: new Date(),
      service: 'REGISTER_CONTROLLER',
      action: 'REGISTER_USER_RES',
      type: 'INFO',
      message: 'register user successfully',
      log: email
    });
    console.log('user', user);
    return res.status(201).json({
      message: 'User registered successfully',
      user: {
        id: user._id,
        email: user.email
      }
    });
  } catch (error) {
    console.error('Failed to register user', error);
    log.info('', {
      timestamp: new Date(),
      service: 'REGISTER_CONTROLLER',
      action: 'REGISTER_USER_RES',
      type: 'ERROR',
      message: 'service error',
      log: error.message || error.stack
    });
    return res.status(500).json({
      error: 'Failed to register user'
    });
  }
};
const login = async (req, res) => {
  try {
    const {
      email,
      password
    } = req.body;
    log.info('', {
      timestamp: new Date(),
      service: 'LOGIN_CONTROLLER',
      action: 'LOGIN_USER_REQ',
      type: 'INFO',
      message: 'Login request is received from a user',
      log: email
    });
    if (!validateEmail(email)) {
      log.info('', {
        timestamp: new Date(),
        service: 'LOGIN_CONTROLLER',
        action: 'LOGIN_USER_RES',
        type: 'ERROR',
        message: 'Invalid email address',
        log: email
      });
      return res.status(400).json({
        error: 'Invalid email address'
      });
    }
    const existingUser = await repository_userRepository.findByEmail(email);
    if (!existingUser) {
      log.info('', {
        timestamp: new Date(),
        service: 'LOGIN_CONTROLLER',
        action: 'LOGIN_USER_RES',
        type: 'ERROR',
        message: 'Email not registered',
        log: email
      });
      return res.status(400).json({
        error: 'Email not registered'
      });
    }
    if (!validatePassword(password)) {
      log.info('', {
        timestamp: new Date(),
        service: 'LOGIN_CONTROLLER',
        action: 'LOGIN_USER_RES',
        type: 'ERROR',
        message: 'Invalid password format',
        log: email
      });
      return res.status(400).json({
        error: 'Invalid password format'
      });
    }
    const passwordMatch = await external_bcryptjs_namespaceObject.compare(password, existingUser.password);
    if (!passwordMatch) {
      log.info('', {
        timestamp: new Date(),
        service: 'LOGIN_CONTROLLER',
        action: 'LOGIN_USER_RES',
        type: 'ERROR',
        message: 'Incorrect password',
        log: email
      });
      return res.status(400).json({
        error: 'Incorrect password'
      });
    }
    const token = external_jsonwebtoken_namespaceObject.sign({
      userId: existingUser._id
    }, process.env.JWT_SECRET, {
      expiresIn: '20m'
    });
    log.info('', {
      timestamp: new Date(),
      service: 'LOGIN_CONTROLLER',
      action: 'LOGIN_USER_RES',
      type: 'INFO',
      message: 'Login successful',
      log: email
    });
    return res.status(200).json({
      message: 'Login successful',
      token
    });
  } catch (error) {
    log.info('', {
      timestamp: new Date(),
      service: 'LOGIN_CONTROLLER',
      action: 'LOGIN_USER_RES',
      type: 'ERROR',
      message: 'Service error',
      log: error.message || error.stack
    });
    return res.status(500).json({
      error: 'Failed to login'
    });
  }
};
const user = async (req, res) => {
  return res.json(req.user);
};
/* harmony default export */ const authController = ({
  register,
  login,
  user
});
;// CONCATENATED MODULE: ./src/middlewares/auth.js

const auth = (req, res, next) => {
  const token = req.headers.authorization && req.headers.authorization.split(' ')[1];
  if (!token) {
    return res.status(401).json({
      message: 'No token provided'
    });
  }
  try {
    const decodedToken = external_jsonwebtoken_namespaceObject.verify(token, process.env.JWT_SECRET);
    req.user = {
      id: decodedToken.userId
    };
    next();
  } catch (error) {
    return res.status(401).json({
      message: 'Invalid token'
    });
  }
};
/* harmony default export */ const middlewares_auth = (auth);
;// CONCATENATED MODULE: ./src/routes/authRoutes.js
// src/routes/authRoutes.js



const router = external_express_namespaceObject.Router();
router.post('/register', authController.register);
router.post('/login', authController.login);
router.get('/user', middlewares_auth, authController.user);
/* harmony default export */ const authRoutes = (router);
;// CONCATENATED MODULE: external "axios"
const external_axios_namespaceObject = require("axios");
;// CONCATENATED MODULE: ./src/services/movies/movies.js

const API_KEY = process.env.MOVIE_API_KEY || '';
const BASE_URL = process.env.MOVIE_BASE_URL || '';
const getMoviesFromApi = async page => {
  try {
    const params = {};
    const route = `${BASE_URL}/now_playing`;
    if (page) {
      params.page = page;
    }
    const headers = {
      Authorization: `Bearer ${API_KEY}`,
      accept: 'application/json'
    };
    const response = await external_axios_namespaceObject.get(route, {
      params,
      headers
    });
    return response.data;
  } catch (error) {
    console.error('Error fetching movies from TMDb:', error);
    throw new Error('Could not fetch movies');
  }
};
const getDetailsFromApi = async id => {
  try {
    if (!id) {
      throw new Error('Movie ID is required');
    }
    const route = `${BASE_URL}/${id}`;
    const headers = {
      Authorization: `Bearer ${API_KEY}`,
      accept: 'application/json'
    };
    const response = await external_axios_namespaceObject.get(route, {
      headers
    });
    return response.data;
  } catch (error) {
    console.error('Error fetching movies from TMDb:', error.message || error.stack);
    throw new Error('Could not fetch movies');
  }
};
/* harmony default export */ const movies_movies = ({
  getMoviesFromApi,
  getDetailsFromApi
});
;// CONCATENATED MODULE: ./src/controllers/movieController.js


const getMovies = async (req, res) => {
  const {
    page
  } = req.query;
  try {
    log.info('', {
      timestamp: new Date(),
      service: 'MOVIE_CONTROLLER',
      action: 'GET_MOVIES_REQ',
      type: 'INFO',
      message: 'A user request the list of movies',
      log: page
    });
    const movies = await movies_movies.getMoviesFromApi(page);
    log.info('', {
      timestamp: new Date(),
      service: 'MOVIE_CONTROLLER',
      action: 'GET_MOVIES_RES',
      type: 'INFO',
      message: 'Movies are fetched successfully',
      log: page
    });
    res.status(200).json({
      message: 'Movies fetched successfully',
      movies
    });
  } catch (error) {
    log.info('', {
      timestamp: new Date(),
      service: 'MOVIE_CONTROLLER',
      action: 'GET_MOVIES_RES',
      type: 'ERROR',
      message: 'Movies are fetched successfully',
      log: error.message || error.stack
    });
    res.status(500).json({
      error: error.message
    });
  }
};
const getMoviesById = async (req, res) => {
  const {
    id
  } = req.params;
  try {
    log.info('', {
      timestamp: new Date(),
      service: 'MOVIE_CONTROLLER',
      action: 'GET_MOVIES_ID_REQ',
      type: 'INFO',
      message: 'A user request the detail for one movie',
      log: id
    });
    const movie = await movies_movies.getDetailsFromApi(id);
    log.info('', {
      timestamp: new Date(),
      service: 'MOVIE_CONTROLLER',
      action: 'GET_MOVIES_ID_RES',
      type: 'INFO',
      message: 'Movie are fetched successfully',
      log: id
    });
    res.status(200).json({
      message: 'Movies fetched successfully',
      movie
    });
  } catch (error) {
    log.info('', {
      timestamp: new Date(),
      service: 'MOVIE_CONTROLLER',
      action: 'GET_MOVIES_ID_REQ',
      type: 'ERROR',
      message: 'Movies are fetched successfully',
      log: error.message || error.stack
    });
    res.status(500).json({
      error: error.message
    });
  }
};
/* harmony default export */ const movieController = ({
  getMovies,
  getMoviesById
});
;// CONCATENATED MODULE: ./src/routes/movieRoutes.js



const movieRoutes_router = external_express_namespaceObject.Router();
movieRoutes_router.get('/list', middlewares_auth, movieController.getMovies);
movieRoutes_router.get('/:id', middlewares_auth, movieController.getMoviesById);
/* harmony default export */ const movieRoutes = (movieRoutes_router);
;// CONCATENATED MODULE: ./src/controllers/userController.js





const updateUserByEmail = async (req, res) => {
  const {
    id
  } = req.params;
  const updates = req.body;
  try {
    log.info('', {
      timestamp: new Date(),
      service: 'USER_CONTROLLER',
      action: 'UPDATE_USER_REQ',
      type: 'INFO',
      message: 'A update request is received from a user',
      log: {
        id,
        updates
      }
    });
    if (!id) {
      log.info('', {
        timestamp: new Date(),
        service: 'USER_CONTROLLER',
        action: 'UPDATE_USER_RES',
        type: 'ERROR',
        message: 'id cannot be updated',
        log: updates
      });
      return res.status(400).json({
        error: 'Email cannot be updated'
      });
    }
    if (updates.email) {
      log.info('', {
        timestamp: new Date(),
        service: 'USER_CONTROLLER',
        action: 'UPDATE_USER_RES',
        type: 'ERROR',
        message: 'Email cannot be updated',
        log: updates
      });
      return res.status(400).json({
        error: 'Email cannot be updated'
      });
    }
    if (updates.password) {
      if (!validatePassword(updates.password)) {
        log.info('', {
          timestamp: new Date(),
          service: 'USER_CONTROLLER',
          action: 'UPDATE_USER_RES',
          type: 'ERROR',
          message: 'Invalid password',
          log: updates
        });
        return res.status(400).json({
          error: 'Invalid password'
        });
      }
      const hashedPassword = await external_bcryptjs_namespaceObject.hash(updates.password, 10);
      updates.password = hashedPassword;
    }
    const user = await repository_userRepository.updateByEmail(id, updates);
    log.info('', {
      timestamp: new Date(),
      service: 'USER_CONTROLLER',
      action: 'UPDATE_USER_RES',
      type: 'INFO',
      message: 'User updated successfully',
      log: updates
    });
    res.status(200).json({
      message: 'User updated successfully',
      user
    });
  } catch (error) {
    log.info('', {
      timestamp: new Date(),
      service: 'USER_CONTROLLER',
      action: 'UPDATE_USER_RES',
      type: 'ERROR',
      message: 'User updated failed',
      log: error.message || error.stack
    });
    res.status(500).json({
      error: error.message
    });
  }
};
const getFavoriteMovies = async (req, res) => {
  const {
    id
  } = req.params;
  log.info('', {
    timestamp: new Date(),
    service: 'USER_CONTROLLER',
    action: 'GET_FAVORITES_REQ',
    type: 'INFO',
    message: 'User updated successfully',
    log: id
  });
  if (!id) {
    log.info('', {
      timestamp: new Date(),
      service: 'USER_CONTROLLER',
      action: 'GET_FAVORITES_RES',
      type: 'ERROR',
      message: 'Email is required',
      log: id
    });
    return res.status(400).json({
      message: 'Id is required'
    });
  }
  try {
    const user = await repository_userRepository.findById(id);
    if (!user) {
      log.info('', {
        timestamp: new Date(),
        service: 'USER_CONTROLLER',
        action: 'GET_FAVORITES_RES',
        type: 'ERROR',
        message: 'User not found',
        log: id
      });
      return res.status(404).json({
        message: 'User not found'
      });
    }
    const favoriteMovieIds = user.favorites || [];
    const movieDetailsPromises = favoriteMovieIds.map(id => movies_movies.getDetailsFromApi(id));
    const results = await Promise.allSettled(movieDetailsPromises);
    const successfulMovies = results.filter(result => result.status === 'fulfilled').map(result => result.value);
    log.info('', {
      timestamp: new Date(),
      service: 'USER_CONTROLLER',
      action: 'GET_FAVORITES_RES',
      type: 'INFO',
      message: 'Favorite movies fetched successfully',
      log: successfulMovies
    });
    res.status(200).json(successfulMovies);
  } catch (error) {
    res.status(500).json({
      error: error.message
    });
  }
};
/* harmony default export */ const userController = ({
  updateUserByEmail,
  getFavoriteMovies
});
;// CONCATENATED MODULE: ./src/routes/userRoutes.js



const userRoutes_router = external_express_namespaceObject.Router();
userRoutes_router.patch('/:id', middlewares_auth, userController.updateUserByEmail);
userRoutes_router.get('/favorites/:id', middlewares_auth, userController.getFavoriteMovies);
/* harmony default export */ const userRoutes = (userRoutes_router);
;// CONCATENATED MODULE: ./src/config/cors.js
const corsConfig = {
  origin: function (origin, callback) {
    const whitelist = [process.env.FRONTEND_URL, process.env.APIGATEWAY_URL];
    if (process.argv[2] === '--api') {
      whitelist.push(undefined);
    }
    if (whitelist.includes(origin)) {
      callback(null, true);
    } else {
      callback(new Error('Error de CORS'));
    }
  }
};
;// CONCATENATED MODULE: external "cors"
const external_cors_namespaceObject = require("cors");
;// CONCATENATED MODULE: ./src/index.js







const app = external_express_namespaceObject();
app.use(external_cors_namespaceObject(corsConfig));
app.use(external_express_namespaceObject.json());
app.use('/auth', authRoutes);
app.use('/movies', movieRoutes);
app.use('/users', userRoutes);
/* harmony default export */ const src = (app);
;// CONCATENATED MODULE: ./src/db/db.js

class Db {
  constructor() {
    console.log('************* SE CREA INSTANCIA DE Db singleton *************');
  }
  async connect() {
    const uri = `${process.env.MONGO_URI}`;
    try {
      await external_mongoose_namespaceObject.connect(uri, {
        maxPoolSize: 200
      });
      console.log('Conexión exitosa a la BD');
    } catch (error) {
      console.error('Error al conectar a la BD:', error);
      throw error;
    }
  }
  getConnection() {
    return this.connect();
  }
}
const dbInstance = new Db();
/* harmony default export */ const db = (dbInstance);
;// CONCATENATED MODULE: ./src/handler.js




async function getConnection() {
  await db.getConnection();
}
const handler = external_serverless_http_namespaceObject(src);
module.exports.handler = async (event, context) => {
  await getConnection();
  const result = await handler(event, context);
  return result;
};
var __webpack_export_target__ = exports;
for(var i in __webpack_exports__) __webpack_export_target__[i] = __webpack_exports__[i];
if(__webpack_exports__.__esModule) Object.defineProperty(__webpack_export_target__, "__esModule", { value: true });
/******/ })()
;
//# sourceMappingURL=handler.js.map